package com.grantburgess.ports.usescases.addoffer;

public interface AddOfferInputBoundary {
    void execute(AddOfferRequest request);
}
