package com.grantburgess.ports.usescases.get.offers;

public class GetOffersRequest {
}
