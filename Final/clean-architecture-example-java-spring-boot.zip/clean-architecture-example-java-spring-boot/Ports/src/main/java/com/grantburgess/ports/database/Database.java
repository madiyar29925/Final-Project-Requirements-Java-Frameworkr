package com.grantburgess.ports.database;

public interface Database {
    OfferGateway offerGateway();
}
