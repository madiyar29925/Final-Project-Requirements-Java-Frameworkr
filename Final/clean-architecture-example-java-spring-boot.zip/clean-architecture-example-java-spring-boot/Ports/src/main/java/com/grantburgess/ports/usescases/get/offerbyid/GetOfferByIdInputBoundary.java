package com.grantburgess.ports.usescases.get.offerbyid;

public interface GetOfferByIdInputBoundary {
    void execute(GetOfferRequest request);
}
