package com.grantburgess.ports.usescases.canceloffer;

public interface CancelOfferInputBoundary {
    void execute(CancelOfferRequest request);
}
