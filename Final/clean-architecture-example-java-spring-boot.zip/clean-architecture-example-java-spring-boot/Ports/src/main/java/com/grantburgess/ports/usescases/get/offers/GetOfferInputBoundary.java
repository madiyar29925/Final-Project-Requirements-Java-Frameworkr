package com.grantburgess.ports.usescases.get.offers;

public interface GetOfferInputBoundary {
    void execute(GetOffersRequest request);
}
