package com.baeldung.service.locator;

public interface MessagingService {

    String getMessageBody();

    String getServiceName();
}
