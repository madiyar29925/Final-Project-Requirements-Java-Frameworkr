module com.baeldung.dip.entities {
    exports com.baeldung.dip.entities;
}
