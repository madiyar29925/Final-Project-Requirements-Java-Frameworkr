package com.baeldung.creational.abstractfactory;

public interface Color {
    String getColor();
}
