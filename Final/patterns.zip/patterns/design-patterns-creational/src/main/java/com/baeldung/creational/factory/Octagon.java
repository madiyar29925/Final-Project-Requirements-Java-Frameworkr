package com.baeldung.creational.factory;

public class Octagon implements Polygon {

    @Override
    public String getType() {
        return "Octagon";
    }

}
