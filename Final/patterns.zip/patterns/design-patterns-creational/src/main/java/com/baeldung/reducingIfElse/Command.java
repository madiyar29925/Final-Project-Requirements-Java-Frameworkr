package com.baeldung.reducingIfElse;

public interface Command {
    Integer execute();
}