package com.baeldung.creational.factory;

public class Heptagon implements Polygon {

    @Override
    public String getType() {
        return "Heptagon";
    }

}
