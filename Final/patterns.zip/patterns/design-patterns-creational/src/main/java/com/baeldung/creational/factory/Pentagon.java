package com.baeldung.creational.factory;

public class Pentagon implements Polygon {

    @Override
    public String getType() {
        return "Pentagon";
    }

}
