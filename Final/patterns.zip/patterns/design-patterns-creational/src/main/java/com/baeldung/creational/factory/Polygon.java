package com.baeldung.creational.factory;

public interface Polygon {
    String getType();
}
