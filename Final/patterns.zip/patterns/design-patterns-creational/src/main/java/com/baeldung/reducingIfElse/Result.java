package com.baeldung.reducingIfElse;

public class Result {
    int value;

    public Result(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
