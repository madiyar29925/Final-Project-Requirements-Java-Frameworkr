package com.baeldung.creational.abstractfactory;

public class Brown implements Color {

    @Override
    public String getColor() {
        return "brown";
    }

}
