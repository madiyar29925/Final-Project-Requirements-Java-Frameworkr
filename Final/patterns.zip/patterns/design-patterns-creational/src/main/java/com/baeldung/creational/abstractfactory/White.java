package com.baeldung.creational.abstractfactory;

public class White implements Color {

    @Override
    public String getColor() {
        return "White";
    }

}
