package com.baeldung.reducingIfElse;

public interface Operation {
    int apply(int a, int b);
}
