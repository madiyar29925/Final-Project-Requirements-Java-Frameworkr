This module contains articles about composing together CQRS and Event Sourcing

## Relevant Articles

- [CQRS and Event Sourcing in Java](https://www.baeldung.com/cqrs-event-sourcing-java)
