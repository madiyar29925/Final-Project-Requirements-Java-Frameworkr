## Patterns

This module contains articles about design patterns.
