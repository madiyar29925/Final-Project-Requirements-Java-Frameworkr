package com.baeldung.d;

public class Monitor {


}
