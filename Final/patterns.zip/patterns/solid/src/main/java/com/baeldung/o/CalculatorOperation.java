package com.baeldung.o;

public interface CalculatorOperation {

    void perform();

}
