package com.baeldung.i;

public interface BearKeeper {

  void washTheBear();
  void feedTheBear();
  void petTheBear();

}
