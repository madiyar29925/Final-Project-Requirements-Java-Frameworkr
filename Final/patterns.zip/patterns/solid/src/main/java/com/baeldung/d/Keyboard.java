package com.baeldung.d;

public interface Keyboard {
}
