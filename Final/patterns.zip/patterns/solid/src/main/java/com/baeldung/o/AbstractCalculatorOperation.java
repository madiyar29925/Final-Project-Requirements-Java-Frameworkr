package com.baeldung.o;

public abstract class AbstractCalculatorOperation {

	abstract void perform();

}
