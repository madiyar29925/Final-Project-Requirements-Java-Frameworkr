package com.baeldung.i;

public class CrazyPerson implements BearPetter {

  public void petTheBear() {
    //Good luck with that!
  }
}
