package com.baeldung.o;

public class Guitar {

  private String make;
  private String model;
  private int volume;

  //Constructors, getters & setters
}
