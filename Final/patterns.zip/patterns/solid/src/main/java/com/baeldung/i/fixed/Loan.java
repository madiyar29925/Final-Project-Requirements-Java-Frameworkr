package com.baeldung.i.fixed;

public interface Loan extends Payment {
    void intiateLoanSettlement();
    void initiateRePayment();
}
