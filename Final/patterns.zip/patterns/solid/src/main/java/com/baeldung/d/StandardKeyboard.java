package com.baeldung.d;

public class StandardKeyboard implements Keyboard {

}
