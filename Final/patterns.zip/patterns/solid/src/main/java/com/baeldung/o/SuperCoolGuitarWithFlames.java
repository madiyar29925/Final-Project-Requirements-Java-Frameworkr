package com.baeldung.o;

public class SuperCoolGuitarWithFlames extends Guitar {

  private String flameColour;

  //constructor, getters + setters

}
