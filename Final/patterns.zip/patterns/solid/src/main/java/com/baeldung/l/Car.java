package com.baeldung.l;

public interface Car {

  void turnOnEngine();
  void accelerate();

}
