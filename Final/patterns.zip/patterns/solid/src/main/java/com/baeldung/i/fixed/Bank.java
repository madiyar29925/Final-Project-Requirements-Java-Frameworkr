package com.baeldung.i.fixed;

public interface Bank extends Payment {
    void initiatePayments();
}
