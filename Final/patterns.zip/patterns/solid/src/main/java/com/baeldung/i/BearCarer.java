package com.baeldung.i;

public class BearCarer implements BearCleaner, BearFeeder {

  public void washTheBear() {
    //I think we missed a spot..
  }

  public void feedTheBear() {
    //Tuna tuesdays..
  }
}
