package com.baeldung.i;

public interface BearFeeder {
  void feedTheBear();
}
