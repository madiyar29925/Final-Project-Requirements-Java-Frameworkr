package com.baeldung.i;

public interface BearPetter {
  void petTheBear();
}
