package com.baeldung.l;

public class Engine {

  public void on(){
    //vroom.
  }

  public void powerOn(int amount){
    //do something
  }

}
