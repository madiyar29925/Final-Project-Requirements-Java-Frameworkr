package com.baeldung.patterns.intercepting.filter.filters;

public interface OnIntercept {
    void intercept();
}
