package com.baeldung.proxy;

public interface ExpensiveObject {
    void process();
}
