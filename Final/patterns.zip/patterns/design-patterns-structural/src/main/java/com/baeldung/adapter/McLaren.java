package com.baeldung.adapter;

public class McLaren implements Movable {
    @Override
    public double getSpeed() {
        return 241;
    }
}
