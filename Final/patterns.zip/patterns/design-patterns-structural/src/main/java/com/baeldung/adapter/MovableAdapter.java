package com.baeldung.adapter;

public interface MovableAdapter {
    // returns speed in KMPH 
    double getSpeed();
}
