package com.baeldung.decorator;

public interface ChristmasTree {
    String decorate();
}