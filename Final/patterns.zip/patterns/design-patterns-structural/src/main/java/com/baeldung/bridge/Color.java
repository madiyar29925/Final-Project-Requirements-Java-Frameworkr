package com.baeldung.bridge;

public interface Color {
    String fill();
}
