package com.baeldung.composite;

/**
 * Created by Gebruiker on 5/1/2018.
 */
public interface Department {

    void printDepartmentName();
}
