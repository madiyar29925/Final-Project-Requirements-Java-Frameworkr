package com.baeldung.adapter;

public class AstonMartin implements Movable {
    @Override
    public double getSpeed() {
        return 220;
    }
}
