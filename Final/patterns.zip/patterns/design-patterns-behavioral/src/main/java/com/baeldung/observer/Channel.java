package com.baeldung.observer;

public interface Channel {
    public void update(Object o);
}
