package com.baeldung.chainofresponsibility;

public class SamlAuthenticationProvider implements AuthenticationProvider {

}
