package com.baeldung.chainofresponsibility;

public class UsernamePasswordProvider implements AuthenticationProvider {

}
