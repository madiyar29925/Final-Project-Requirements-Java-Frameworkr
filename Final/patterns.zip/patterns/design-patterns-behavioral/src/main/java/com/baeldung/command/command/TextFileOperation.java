package com.baeldung.command.command;

@FunctionalInterface
public interface TextFileOperation {
    
    String execute();
    
}
