package com.baeldung.nullobject;

public interface Router {

    void route(Message msg);

}
