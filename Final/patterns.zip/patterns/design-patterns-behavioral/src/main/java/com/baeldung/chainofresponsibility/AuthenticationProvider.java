package com.baeldung.chainofresponsibility;

public interface AuthenticationProvider {

}
