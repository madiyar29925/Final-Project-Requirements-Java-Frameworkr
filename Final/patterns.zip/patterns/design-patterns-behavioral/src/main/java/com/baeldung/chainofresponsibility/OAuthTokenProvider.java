package com.baeldung.chainofresponsibility;

public class OAuthTokenProvider implements AuthenticationProvider {

}
